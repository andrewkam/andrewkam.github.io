% segmentShuffle.m
%
% Andrew Kam
% Final Project
%
% This function randomly shuffles the stream based on the segment locations
% indicated in the segments variable.

function output = segmentShuffle(stream, segments, segmentCount)
    % randomize segments
    segmentClusters = cell(segmentCount, 1);
    segmentOrder = randperm(segmentCount - 1);
    segmentOrder = [segmentOrder segmentCount];

    % shuffle the segments based on randomization
    for i = 1:segmentCount
        segmentClusters{i} = segments(1,segmentOrder(i)):segments(2,segmentOrder(i));
    end
    
    segmentIndex = cat(2, segmentClusters{:})';
    
    output = stream(segmentIndex);
end