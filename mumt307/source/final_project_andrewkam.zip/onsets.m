% onsets.m
%
% Andrew Kam
% Final Project
%
% This function determines the locations of each laugh onset

function output = onsets(stream, Fs)
    waveform = miraudio(stream, Fs);
    env = mirenvelope(waveform);        % convert audio to mirenvelope form
    valleys = mirpeaks(env, 'Valleys'); % find valleys
    valleys = mirgetdata(valleys);      % get valley locations
    valleys = sortrows(valleys);
    valleys = round(valleys.*Fs);
    
    output = valleys;
end