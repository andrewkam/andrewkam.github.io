% streamAmplitude.m
%
% Andrew Kam
% Final Project
%
% This function alters the overall amplitude of the stream to a random
% degree

function output = streamAmplitude(stream, amplitudeRange)
    normStream = stream/norm(stream, Inf);
    amplitudeFactor = randi([0 amplitudeRange*100], 1, 1);
    amplitudeFactor = 1.0 - (amplitudeFactor * 0.01);
    
    output = normStream * amplitudeFactor;
end