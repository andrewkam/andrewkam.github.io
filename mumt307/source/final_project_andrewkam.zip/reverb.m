% reverb.m
%
% Andrew Kam
% Final Project
%
% This function adds reverb to the stream by convolviing it with an
% impulse. The impulse must be an audio file.

function output = reverb(stream, filename)
    impulse = audioread(filename);
    
    output = conv(stream, impulse);
end