% streamDelay.m
%
% Andrew Kam
% Final Project
%
% This function creates a silence at the beginning of the stream of random
% length.

function output = streamDelay(stream, delayLength)
    delayNum = randi([1 delayLength], 1, 1);

    frontPad = zeros(delayNum, 1);
    endPad = zeros(delayLength - delayNum, 1);
    
    stream = [frontPad; stream; endPad];
    
    output = stream;
end