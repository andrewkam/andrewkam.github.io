% silence.m
%
% Andrew Kam
% Final Project
%
% This function removes the silence from the beginning of the input stream

function output = silence(stream, Fs)
    waveform = miraudio(stream, Fs);
    silence = miraudio(waveform, 'TrimStart');
    silence = mirgetdata(silence);
    
    output = length(stream) - length(silence);
end