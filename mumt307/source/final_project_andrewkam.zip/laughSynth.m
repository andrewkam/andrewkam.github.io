% laughsynth.m
%
% Andrew Kam
% Final Project
%
% This is the main function to execute the laugh track synth
% Parameters:
% inputAudio = input audio filename
% sampleRate = sampling frequency
% streamCount = number of streams to create
% reverbFlag = 1 to enable reverb, 0 to disable reverb

function output = laughSynth(inputAudio, sampleRate, streamCount, reverbFlag) 
    Fs = sampleRate;
    delayFraction = 0.15;
    amplitudeRange = 0.2;
    stream = cell(streamCount, 1);
    lengthMax = 0;

    % initialize some variables used in configuring the System objects
    WindowLen = 1024;
    AnalysisLen = 64;
    SynthesisLenMin = 42;   % set range of pitch-shifting
    SynthesisLenMax = 72;

    % get random pitch variations, leave first stream as original pitch
    SynthesisLen = randi([SynthesisLenMin SynthesisLenMax],1,streamCount);
    SynthesisLen(1) = AnalysisLen;

    % Create a System object to read in the input speech signal from an audio file.
    reader = dsp.AudioFileReader(inputAudio,'SamplesPerFrame', AnalysisLen,'OutputDataType','double');

    % duplicate, pitch-shift, time-stretch the original stream for the number
    % of specified times
    for i = 1:streamCount

        % time-stretch
        pitchShiftOut = pitchshift(reader, WindowLen, AnalysisLen, SynthesisLen(i));
        
        % add chorus effect
        chorus = audioexample.Chorus('Delay', 0.05, 'WetDryMix', 0.6);
        chorusOut = chorus(pitchShiftOut);

        % Resample to add pitch-shifting.
        % The pitch-scaled signal is the time-stretched signal played at a higher
        % sampling rate which produces a signal with a higher pitch.
        stream{i} = resample(chorusOut, AnalysisLen, SynthesisLen(i));

        reset(reader);
    end

    % close any files
    release(reader);

    % find silence at the beginning of audio
    silenceIndex = silence(stream{1}, Fs);

    % cut out silence from each of the streams
    for i = 1:streamCount
        stream{i} = stream{i}(silenceIndex:end);

        if length(stream{i}) > lengthMax
            lengthMax = length(stream{i});
        end
    end

    % get the valleys of the original waveform
    valleys = onsets(stream{1}, Fs);

    % cut out false segments at the beginning and end
    if (valleys(1) == 0)
        valleys = valleys(2:end);
    end

    if (max(stream{1}(valleys(end):end)) < 0.05)
        valleys = valleys(1:end-1);
    end

    valleyCount = length(valleys);
    segmentCount = valleyCount+1;

    % calculate segments
    segments = repelem(valleys, 2);
    segments = [0;segments;lengthMax];
    segments = reshape(segments, [2,segmentCount]);
    segments(1,:) = segments(1,:) + 1;

    % calculate padding for delay
    delayLength = round(lengthMax * delayFraction);

    % create resulting laugh track matrix
    laughMatrix = zeros(lengthMax + delayLength, streamCount);

    % pad each stream with zeros so they all line up
    for i = 1:streamCount
        tempStream = [stream{i}; zeros(lengthMax - length(stream{i}), 1)];
        tempStream = segmentShuffle(tempStream, segments, segmentCount);
        tempStream = streamDelay(tempStream, delayLength);
        tempStream = streamAmplitude(tempStream, amplitudeRange);
        laughMatrix(:,i) = tempStream;
    end

    % create resulting track from all the streams
    laughTrack = sum(laughMatrix, 2);

    % add reverb if flag is true
    if (reverbFlag == 1)
        laughTrack = reverb(laughTrack, 'IRauditorium.wav');
    end

    % normalize audio
    laughTrack = 2 * mat2gray(laughTrack) - 1;

    output = laughTrack;
end